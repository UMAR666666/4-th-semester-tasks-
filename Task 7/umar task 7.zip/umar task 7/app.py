import requests
from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    url = "https://icanhazdadjoke.com/"
    headers = {"Accept": "application/json"}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        joke_data = response.json()
    else:
        joke_data = {"error": "Could not fetch joke"}

    return render_template("index.html", data=joke_data)


@app.route("/joke/<joke_id>")
def get_specific_joke(joke_id):
    url = f"https://icanhazdadjoke.com/j/{joke_id}"
    headers = {"Accept": "application/json"}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        joke_data = response.json()
    else:
        joke_data = {"error": "Joke not found"}

    return render_template("index.html", data=joke_data)


if __name__ == "__main__":
    app.run(debug=True)