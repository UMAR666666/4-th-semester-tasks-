from flask import Flask, render_template, request, send_file
import pandas as pd
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re
import time

app = Flask(__name__)

EMAIL_REGEX = r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"

def crawl_website(start_url, max_pages=10):

    visited = set()
    to_visit = [start_url]
    emails = set()

    domain = urlparse(start_url).netloc

    while to_visit and len(visited) < max_pages:

        url = to_visit.pop(0)

        if url in visited:
            continue

        visited.add(url)

        try:
            r = requests.get(url, timeout=8)
            html = r.text

            found = re.findall(EMAIL_REGEX, html)

            for email in found:
                emails.add(email)

            soup = BeautifulSoup(html, "html.parser")

            for link in soup.find_all("a", href=True):

                new_url = urljoin(url, link["href"])

                if urlparse(new_url).netloc == domain and new_url not in visited:
                    to_visit.append(new_url)

        except:
            continue

        time.sleep(0.5)

    return list(emails)


@app.route("/", methods=["GET", "POST"])
def index():

    results = []

    if request.method == "POST":

        file = request.files["file"]

        df = pd.read_excel(file)

        urls = df["url"].dropna()

        for url in urls:

            emails = crawl_website(url)

            results.append({
                "Website": url,
                "Emails": ", ".join(emails)
            })

        # Save results
        result_df = pd.DataFrame(results)
        result_df.to_excel("emails_result.xlsx", index=False)

    return render_template("index.html", results=results)


@app.route("/download")
def download():
    return send_file("emails_result.xlsx", as_attachment=True)


if __name__ == "__main__":
    app.run(debug=True)