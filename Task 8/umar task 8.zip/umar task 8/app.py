import requests
from flask import Flask, render_template, jsonify

app = Flask(__name__)

BASE_URL = "https://icanhazdadjoke.com/"
HEADERS = {"Accept": "application/json"}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get-joke")
def get_joke():
    try:
        response = requests.get(BASE_URL, headers=HEADERS, timeout=5)
        response.raise_for_status()
        return jsonify(response.json())
    except requests.exceptions.RequestException:
        return jsonify({"error": "Could not fetch joke. Check your internet."})

if __name__ == "__main__":
    app.run(debug=True)